# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#%% List comprehension
lst = [x for x in 'word']
lst
#%% Check for even numbers in a range
lst = [x for x in range(0, 20) if x%2 == 0]
lst
#%% 
celsius = [0, 10, 20.1, 34.5]

fahrenheit = [(float(9)/5)*cels + 32 for cels in celsius]
fahrenheit
#%%
lst = [x**2 for x in [x**2 for x in range(11)]]
lst
#%%
sentence = "the quick brown fox jumps over the lazy dog"
words = sentence.split()
words

words_length = []

for word in words:
    if word != 'the':
        words_length.append(len(word))
        
print(words_length)

#%%
word_length = [len(word) for word in words if word != 'the']
word_length
#%%variable lenght arguments

def f(*args, **kwargs):
    #print(args[0] + args[1] + args[2])
    y = kwargs.get("c")
    print(f"x: , y:{y}")
    print("Inside f")

f(a = 55, b = 85, c = 96)
#%%
x = [3, "Python", 12.2]

#indexing
print(x[-1])    

#slicing
print(x[0:-1])
#%%
print(sentence.partition("lazy"))
    


















