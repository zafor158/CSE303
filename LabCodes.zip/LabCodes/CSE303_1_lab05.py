# -*- coding: utf-8 -*-
"""
Created on Mon Nov 22 17:28:20 2021

@author: User
"""

import numpy as np

#%%
A = np.array([1,2,3,4,5,6])
print(A)

B = np.array([10,20,30,40,50,60])
print(B)

print(A+B)

print(A-B)
#%%
list1 = [1,2,3,4,5,6]
print(list1)

list2 = [10,20,30,40,50,60]
print(list2)

print(list1+list2)

print(list1-list2)

#%%

temp = np.array([10, 15, 20.5, 30, 37])

temp_fahrenheit = temp * 1.8 + 32

print(temp_fahrenheit)

#%%

print(A.shape)

#%%

M1 = np.array([[1,2,3],[4,5,6]]) 
# 1 2 3
# 4 5 6
M2 = np.array([[7,8,9],[3,4,5]])
# 7 8 9
# 3 4 5

print(M1)
print(M2)
print(M1.shape)
#%%

M3 = M1+M2
M4 = M1-M2
M5 = M1*M2 #scalar multiplication
M6 = M1/M2

print(M3)

print(M4)

print(M5)

print(M6)

#%%

M1 = np.array([[1,2,3],[4,5,6],[7,8,9]]) 

M7 = M1[:,0:2]

print(M7)

#%%
# slice the last rows with last two columns


M8 = M1[-1,-2:]
print(M8)

#%%

M9 = np.array([[1,2,3,4],[56, 43, 23, 78],
               [100, 101, 102, 103]])
#   1   2   3   4
#  56  43  23  78
# 100 101 102 103

bool_idx = (M9%2==0)

print(bool_idx)
#%%

print(M9[bool_idx])

#%%
print(M9[M9%2==0])
#%%
M1 = np.array([[1,2,3],[4,5,6],[7,8,9]]) 

M2 = np.array([[-1,-2,-3],[-4,-5,-6],[-7,-8,-9]])
print(np.add(M1, M2))

print(np.subtract(M1, M2))

print(np.multiply(M1, M2))

print(np.divide(M1, M2))

print(np.sqrt(M1))

#%%

x = np.array([[1,2],[3,4]])
# 1 2       5 6
# 3 4       7 8

# 1.5+2.7   1.6+2.8     19  22   
# 3.5+4.7   3.6+4.8     43  50

y = np.array([[5,6],[7,8]])

print(x.dot(y))

#%%
print(np.dot(x,y))
print(x@y)
print(np.matmul(x,y))

#%%
# Write your own Python code (without using any numpy function)
# performing Matrix-Matrix multiplication)


#%%

v1 = np.array([1,2,3]) # i+2j+3k
v2 = np.array([-1,3,-2]) # -i+3j-2k

# 1.-1+2.3-3.2 = -1

print(np.dot(v1, v2))

#%%

x = np.array([[1,2],[3,4],[5,6]]) # shape(3, 2)
# 1 2  
# 3 4
# 5 6 

# 1 3 5     # 1 2 3     1.1+3.2+5.3 = 22
# 2 4 6                 2.1+4.2+6.3 = 28
   
v1 = np.array([1,2,3])  #shape(3,) here 3 is no. of col
# print(x.shape)
# print(v1.shape)
print(np.dot(np.transpose(x),v1))

#%%

data1 = np.arange(10)
print(data1)
print(np.average(data1))

#%%

data2 = np.arange(12).reshape(4,3)
print(data2)

#%%
print(np.average(data2, axis = 0))
print(np.average(data2, axis = 1))

[[ 0  1  2]
 [ 3  4  5]
 [ 6  7  8]
 [ 9 10 11]]
#%%
print(np.sum(data2)) #66

#%%
print(np.sum(data2, axis = 0)) # col-wise
print(np.sum(data2, axis = 1)) # row-wise

#%%


M11 = np.zeros((3,3))
print(M11)

#%%
M12 = np.random.rand(3,3)
print(M12)

#%%

M13 = np.linspace(0, 90, 10).reshape(2, 5)
print(M13)

#%%
M14 = np.eye(4)
print(M14)

#%%

data2 = np.arange(12).reshape(4,3)
print(data2)

#[[ 0  1  2]    [10 20 30]
# [ 3  4  5]
# [ 6  7  8]
# [ 9 10 11]]

v3 = np.array([10, 20, 30])

Z = data2 + v3
print(Z)

#%%
[[10 21 32]
 [13 24 35]
 [16 27 38]
 [19 30 41]]

#%%
v4 = np.array([1, 2, 3, 4])

Z1 = np.transpose(data2) + v4

print(Z1)

#%%

import matplotlib.pyplot as plt
import numpy as np
#%%

x = np.array([10, 15, 20])
y = np.array([5, 9, 7])

plt.plot(x, y, '*')

plt.xlabel('x-axis', fontsize = 12)
plt.ylabel('y-axis', fontsize = 12)

plt.title('Hello world')


#%%

x1 = np.arange(6)
print(x1)

freq = np.linspace(20, 50, 6)
print(freq)

ticklabel = ['Ban', 'Ind', 'Pak', 'Sri', 'Mal', 'Nep']
plt.bar(x1, freq, tick_label = ticklabel, width = 0.8)

plt.xlabel ('x-axis')
plt.ylabel('Frequency')

plt.title ('Bar chart')

plt.show()




















