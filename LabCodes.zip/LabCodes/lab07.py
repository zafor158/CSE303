# -*- coding: utf-8 -*-
"""
Created on Mon Aug  1 17:14:13 2022

@author: Sadab
"""
import numpy as np
import matplotlib.pyplot as plt
#%%
x = np.array([[1,2],[3,4]], dtype =np.int32)
y = np.array([[5,6],[7,8]], dtype= np.int32)
v = np.array([9,10])
w = np.array([11,12])

print('Inner Product: ')
print(v.dot(w))
print(np.dot(v,w))
print(np.inner(v,w))
#%%
print('Outer Product: ')
print(np.outer(v,w))
#%%
print('Norm: ')
print(np.linalg.norm(v))
print(np.linalg.norm(v,2))
print(np.linalg.norm(v,np.inf))
print(np.linalg.norm(x))
print(np.linalg.norm(x, axis = 1))
#%%
print("Matrix: ")
print(x.dot(v))
print(np.dot(x,v))
print("Matrix Multiplication: ")
print(x.dot(y))
print(np.dot(x,y))
print(np.matmul(x,y))
print(x @ y)
#%%
m = np.array([[2,4,6],
              [1,5,9],
              [3,7,8]])
#%%
print("Determinant of a matrix: %.2f"%np.linalg.det(m))
print("Trace: %.2f"%np.trace(m))
print("Rank: ",np.linalg.matrix_rank(m))
#%%
mt1 = m.T
print("Transpose of matrix1: ",mt1)
mt2 = np.transpose(m)
print("Transpose of matrix1: ",mt2)
#%%
inv_m = np.linalg.inv(m)
print("Inverse Matrix: ", inv_m)

A = np.array([[1,2],[3,4]])
z = np.array([[5],[6]])
print('Using Inverse Function:\n', np.linalg.inv(A).dot(z))
print('Using Solve Function:\n', np.linalg.solve(A,z))
#%% Least Squares
x = np.arange(0,9)
A = np.array([x, np.ones(9)])
print(A)
y = [19, 20, 20.5, 21.5, 22, 23, 23, 25.5,24]
w = np.linalg.lstsq(A.T, y, rcond=None)[0]
print(w)
#%%
line = w[0]*x + w[1]
plt.plot(x,line, 'r-')
plt.plot(x,y, 'o')
plt.show()
#%%
A = np.array([[0,1],[-2,-3]])
val, vect = np.linalg.eig(A)
print(val)
print(vect)

#rank of a matrix
# MAX(Columns/Rows) => columns/rows = linearly independent


