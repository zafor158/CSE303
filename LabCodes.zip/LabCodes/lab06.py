# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#%%
import numpy as np
import matplotlib.pyplot as plt
#%%
#x axis values
x =  np.array([1, 2, 3])
#corresponding y axis values
y = np.array([2, 4, 1])

#plotting the points
plt.plot(x, y)
#naming the x axis
plt.xlabel('x-axis')
#naming the y axis
plt.ylabel('y-axis')

#giving title to my graph
plt.title('My first graph')
plt.show()
#%%
plt.figure(figsize = (8,6), dpi = 80)

#create a new subplot from a grid of 1X1
plt.subplot(1,1,1)

X = np.linspace(-np.pi, np.pi, 256, 
                endpoint = True)
C,S =np.cos(X), np.sin(X)

plt.plot(X, C, color = 'red', linewidth = 1.0,
         linestyle = "--", label = "cosine")

plt.plot(X, S, color = 'blue', linewidth = 1.0,
         linestyle = "-", label = "sine")

plt.xlim(-4.0, 4.0)
plt.xticks(np.linspace(-4,4,9))

plt.ylim(-1.0,1.0)
plt.yticks(np.linspace(-1,1,5))

plt.xlabel('x-axis')
plt.ylabel('y-axis')

plt.legend(loc = 'upper left')

plt.title("Sine and Cosine graph")
plt.savefig("sample.png", dpi = 72)
plt.show()
#%%
plt.figure(figsize = (8,6), dpi = 80)

#create a new subplot from a grid of 1X1
plt.subplot(2,1,1)

plt.title("Sine and Cosine graph")
X = np.linspace(-np.pi, np.pi, 256, 
                endpoint = True)
C,S =np.cos(X), np.sin(X)

plt.plot(X, C, color = 'red', linewidth = 1.0,
         linestyle = "--", label = "cosine")
plt.legend(loc = 'upper left')

plt.subplot(2,1,2)
plt.plot(X, S, color = 'blue', linewidth = 1.0,
         linestyle = "-", label = "sine")

plt.xlim(-4.0, 4.0)
plt.xticks(np.linspace(-4,4,9))

plt.ylim(-1.0,1.0)
plt.yticks(np.linspace(-1,1,5))

plt.xlabel('x-axis')
plt.ylabel('y-axis')

plt.legend(loc = 'upper left')

plt.savefig("sample.png", dpi = 72)
plt.show()
#%%
x = np.arange(0, np.pi*2, 0.05)

fig=plt.figure()
axes1 = fig.add_axes([0.1, 0.1, 0.8, 0.8]) # main axes
axes2 = fig.add_axes([0.16, 0.16, 0.3, 0.3]) # inset axes
y = np.sin(x)
axes1.plot(x, y, 'b')
axes2.plot(x,np.cos(x),'r')
axes1.set_title('sine')
axes2.set_title("cosine")
plt.show()








